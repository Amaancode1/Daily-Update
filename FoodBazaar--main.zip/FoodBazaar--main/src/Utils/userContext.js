import { createContext } from "react";

const userContext = createContext({
    loggedInUser: "Vivek Khule",
})
export default userContext;