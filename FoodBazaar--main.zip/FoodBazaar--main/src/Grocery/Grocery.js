import GroceryMid from "./GroceryMid";
import GroceryTop from "./GroceryTop";
import GroceryMid2 from "./GroceryMid2";
import GroceryTopCarousal from "./GroceryTopCarousal";
import GroceryMid3 from "./GroceryMid3";
import GroceryMid4 from "./GrocceryMid4";
import GroceryMid5 from "./GroceryMid5";
import GroceryMid6 from "./GroceryMid6";
import GroceryMid7 from "./GroceryMid7";
import GroceryCategory from "./GroceryCategory";


const Grocery = () => {
  return (
    <div className="">
      <div className="pb-3 lg:pb-2 md:pb-2">
        <img src="https://instamart-media-assets.swiggy.com/swiggy/image/upload/rng/md/carousel/production/a313fb171d73e211fe359175f6f387e6"></img>
      </div>
      {/* <GroceryMid7 /> */}
      <GroceryMid3 />
      {/* <GroceryCategory /> */}
      {/* <GroceryMid5 /> */}
      {/* <GroceryTopCarousal /> */}
      {/* <GroceryTop /> */}
      {/* <GroceryMid /> */}
      {/* <GroceryMid2 /> */}
      {/* <GroceryMid4 /> */}
      {/* <GroceryMid6 /> */}
    </div>
  );
};
export default Grocery;
