import ShimmerCard from "./shimmerCard";

const Shimmer = ()=>{
    return (
        <div>
            <ShimmerCard/>
        </div>
    )
}
export default Shimmer;