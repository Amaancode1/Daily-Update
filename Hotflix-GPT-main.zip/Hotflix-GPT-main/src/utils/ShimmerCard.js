const ShimmerCard = () => {
    return (
        <div>hello coming</div>
    )
}
export default ShimmerCard;